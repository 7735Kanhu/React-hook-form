import React from 'react'
import './Userform.css'
import { useForm } from 'react-hook-form'

const Userform = () => {
    const {register, handleSubmit } = useForm();

    const onSubmit = (data) => {
        console.log(data);
    }
  return (
    <div className='form-group'>
    <h1>Userform</h1>
    <form onSubmit={handleSubmit(onSubmit)}>
        <input type="text" name="name" 
        placeholder="Enter Your name" autoComplete='off' {...register("username")}/>
        <input type="email" name="email" placeholder='Enter Your email' {...register("email")} />
        <input type="password" name="password" placeholder=' Enter Your Password' {...register("password")}/>
        <input type="submit" value="Submit"/>
    </form>
    </div>
  )
}

export default Userform