// import logo from './logo.svg';
import './App.css';
import Userform from './components/Userform';

function App() {
  return (
    <div className="App">
      <Userform />
    </div>
  );
}

export default App;
